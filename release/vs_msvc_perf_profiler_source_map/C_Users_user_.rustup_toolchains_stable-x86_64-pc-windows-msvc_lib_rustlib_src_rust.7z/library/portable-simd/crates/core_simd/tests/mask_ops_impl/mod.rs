#[macro_use]
mod mask_macros;

#[rustfmt::skip]
mod mask8;
mod mask16;
mod mask32;
mod mask64;
mod masksize;
