mask_tests! { mask64x2, 2 }
mask_tests! { mask64x4, 4 }
mask_tests! { mask64x8, 8 }
