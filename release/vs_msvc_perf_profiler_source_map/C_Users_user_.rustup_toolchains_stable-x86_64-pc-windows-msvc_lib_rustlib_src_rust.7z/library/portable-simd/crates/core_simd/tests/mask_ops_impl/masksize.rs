mask_tests! { masksizex2, 2 }
mask_tests! { masksizex4, 4 }
mask_tests! { masksizex8, 8 }
