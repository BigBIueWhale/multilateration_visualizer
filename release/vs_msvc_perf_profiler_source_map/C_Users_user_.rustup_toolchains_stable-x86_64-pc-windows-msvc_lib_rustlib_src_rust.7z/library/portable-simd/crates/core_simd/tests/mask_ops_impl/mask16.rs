mask_tests! { mask16x4, 4 }
mask_tests! { mask16x8, 8 }
mask_tests! { mask16x16, 16 }
mask_tests! { mask16x32, 32 }
