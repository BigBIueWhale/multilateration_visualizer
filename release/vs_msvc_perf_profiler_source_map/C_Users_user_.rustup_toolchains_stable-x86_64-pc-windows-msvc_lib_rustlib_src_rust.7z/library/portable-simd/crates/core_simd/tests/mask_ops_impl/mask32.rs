mask_tests! { mask32x2, 2 }
mask_tests! { mask32x4, 4 }
mask_tests! { mask32x8, 8 }
mask_tests! { mask32x16, 16 }
