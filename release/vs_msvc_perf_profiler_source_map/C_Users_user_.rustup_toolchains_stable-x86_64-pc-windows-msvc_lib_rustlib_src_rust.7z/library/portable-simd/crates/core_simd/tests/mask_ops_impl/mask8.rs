mask_tests! { mask8x8, 8 }
mask_tests! { mask8x16, 16 }
mask_tests! { mask8x32, 32 }
