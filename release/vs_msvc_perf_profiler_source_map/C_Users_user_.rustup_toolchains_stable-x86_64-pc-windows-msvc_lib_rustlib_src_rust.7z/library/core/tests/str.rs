// All `str` tests live in library/alloc/tests/str.rs
