/* eslint-disable */
import {
  ChannelCredentials,
  Client,
  ClientReadableStream,
  handleServerStreamingCall,
  makeGenericClientConstructor,
  Metadata,
} from "@grpc/grpc-js";
import type { CallOptions, ClientOptions, UntypedServiceImplementation } from "@grpc/grpc-js";
import Long from "long";
import _m0 from "protobufjs/minimal";

export const protobufPackage = "workhorse";

/** Empty */
export interface ReadFramesRequest {
}

export interface Voxel {
  color: string;
  opacity: number;
  x: number;
  y: number;
  z: number;
}

export interface FrameData {
  voxels: Voxel[];
}

function createBaseReadFramesRequest(): ReadFramesRequest {
  return {};
}

export const ReadFramesRequest = {
  encode(_: ReadFramesRequest, writer: _m0.Writer = _m0.Writer.create()): _m0.Writer {
    return writer;
  },

  decode(input: _m0.Reader | Uint8Array, length?: number): ReadFramesRequest {
    const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
    let end = length === undefined ? reader.len : reader.pos + length;
    const message = createBaseReadFramesRequest();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skipType(tag & 7);
    }
    return message;
  },

  fromJSON(_: any): ReadFramesRequest {
    return {};
  },

  toJSON(_: ReadFramesRequest): unknown {
    const obj: any = {};
    return obj;
  },

  create<I extends Exact<DeepPartial<ReadFramesRequest>, I>>(base?: I): ReadFramesRequest {
    return ReadFramesRequest.fromPartial(base ?? ({} as any));
  },
  fromPartial<I extends Exact<DeepPartial<ReadFramesRequest>, I>>(_: I): ReadFramesRequest {
    const message = createBaseReadFramesRequest();
    return message;
  },
};

function createBaseVoxel(): Voxel {
  return { color: "", opacity: 0, x: 0, y: 0, z: 0 };
}

export const Voxel = {
  encode(message: Voxel, writer: _m0.Writer = _m0.Writer.create()): _m0.Writer {
    if (message.color !== "") {
      writer.uint32(10).string(message.color);
    }
    if (message.opacity !== 0) {
      writer.uint32(21).float(message.opacity);
    }
    if (message.x !== 0) {
      writer.uint32(48).int64(message.x);
    }
    if (message.y !== 0) {
      writer.uint32(56).int64(message.y);
    }
    if (message.z !== 0) {
      writer.uint32(64).int64(message.z);
    }
    return writer;
  },

  decode(input: _m0.Reader | Uint8Array, length?: number): Voxel {
    const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
    let end = length === undefined ? reader.len : reader.pos + length;
    const message = createBaseVoxel();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          if (tag !== 10) {
            break;
          }

          message.color = reader.string();
          continue;
        case 2:
          if (tag !== 21) {
            break;
          }

          message.opacity = reader.float();
          continue;
        case 6:
          if (tag !== 48) {
            break;
          }

          message.x = longToNumber(reader.int64() as Long);
          continue;
        case 7:
          if (tag !== 56) {
            break;
          }

          message.y = longToNumber(reader.int64() as Long);
          continue;
        case 8:
          if (tag !== 64) {
            break;
          }

          message.z = longToNumber(reader.int64() as Long);
          continue;
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skipType(tag & 7);
    }
    return message;
  },

  fromJSON(object: any): Voxel {
    return {
      color: isSet(object.color) ? globalThis.String(object.color) : "",
      opacity: isSet(object.opacity) ? globalThis.Number(object.opacity) : 0,
      x: isSet(object.x) ? globalThis.Number(object.x) : 0,
      y: isSet(object.y) ? globalThis.Number(object.y) : 0,
      z: isSet(object.z) ? globalThis.Number(object.z) : 0,
    };
  },

  toJSON(message: Voxel): unknown {
    const obj: any = {};
    if (message.color !== "") {
      obj.color = message.color;
    }
    if (message.opacity !== 0) {
      obj.opacity = message.opacity;
    }
    if (message.x !== 0) {
      obj.x = Math.round(message.x);
    }
    if (message.y !== 0) {
      obj.y = Math.round(message.y);
    }
    if (message.z !== 0) {
      obj.z = Math.round(message.z);
    }
    return obj;
  },

  create<I extends Exact<DeepPartial<Voxel>, I>>(base?: I): Voxel {
    return Voxel.fromPartial(base ?? ({} as any));
  },
  fromPartial<I extends Exact<DeepPartial<Voxel>, I>>(object: I): Voxel {
    const message = createBaseVoxel();
    message.color = object.color ?? "";
    message.opacity = object.opacity ?? 0;
    message.x = object.x ?? 0;
    message.y = object.y ?? 0;
    message.z = object.z ?? 0;
    return message;
  },
};

function createBaseFrameData(): FrameData {
  return { voxels: [] };
}

export const FrameData = {
  encode(message: FrameData, writer: _m0.Writer = _m0.Writer.create()): _m0.Writer {
    for (const v of message.voxels) {
      Voxel.encode(v!, writer.uint32(10).fork()).ldelim();
    }
    return writer;
  },

  decode(input: _m0.Reader | Uint8Array, length?: number): FrameData {
    const reader = input instanceof _m0.Reader ? input : _m0.Reader.create(input);
    let end = length === undefined ? reader.len : reader.pos + length;
    const message = createBaseFrameData();
    while (reader.pos < end) {
      const tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          if (tag !== 10) {
            break;
          }

          message.voxels.push(Voxel.decode(reader, reader.uint32()));
          continue;
      }
      if ((tag & 7) === 4 || tag === 0) {
        break;
      }
      reader.skipType(tag & 7);
    }
    return message;
  },

  fromJSON(object: any): FrameData {
    return { voxels: globalThis.Array.isArray(object?.voxels) ? object.voxels.map((e: any) => Voxel.fromJSON(e)) : [] };
  },

  toJSON(message: FrameData): unknown {
    const obj: any = {};
    if (message.voxels?.length) {
      obj.voxels = message.voxels.map((e) => Voxel.toJSON(e));
    }
    return obj;
  },

  create<I extends Exact<DeepPartial<FrameData>, I>>(base?: I): FrameData {
    return FrameData.fromPartial(base ?? ({} as any));
  },
  fromPartial<I extends Exact<DeepPartial<FrameData>, I>>(object: I): FrameData {
    const message = createBaseFrameData();
    message.voxels = object.voxels?.map((e) => Voxel.fromPartial(e)) || [];
    return message;
  },
};

export type MultilateralVisualizerService = typeof MultilateralVisualizerService;
export const MultilateralVisualizerService = {
  /**
   * A return value with keyword "stream" tells gRPC that the
   * function returns multiple times. Like subscribing to a flow of data.
   */
  readFrames: {
    path: "/workhorse.MultilateralVisualizer/read_frames",
    requestStream: false,
    responseStream: true,
    requestSerialize: (value: ReadFramesRequest) => Buffer.from(ReadFramesRequest.encode(value).finish()),
    requestDeserialize: (value: Buffer) => ReadFramesRequest.decode(value),
    responseSerialize: (value: FrameData) => Buffer.from(FrameData.encode(value).finish()),
    responseDeserialize: (value: Buffer) => FrameData.decode(value),
  },
} as const;

export interface MultilateralVisualizerServer extends UntypedServiceImplementation {
  /**
   * A return value with keyword "stream" tells gRPC that the
   * function returns multiple times. Like subscribing to a flow of data.
   */
  readFrames: handleServerStreamingCall<ReadFramesRequest, FrameData>;
}

export interface MultilateralVisualizerClient extends Client {
  /**
   * A return value with keyword "stream" tells gRPC that the
   * function returns multiple times. Like subscribing to a flow of data.
   */
  readFrames(request: ReadFramesRequest, options?: Partial<CallOptions>): ClientReadableStream<FrameData>;
  readFrames(
    request: ReadFramesRequest,
    metadata?: Metadata,
    options?: Partial<CallOptions>,
  ): ClientReadableStream<FrameData>;
}

export const MultilateralVisualizerClient = makeGenericClientConstructor(
  MultilateralVisualizerService,
  "workhorse.MultilateralVisualizer",
) as unknown as {
  new (
    address: string,
    credentials: ChannelCredentials,
    options?: Partial<ClientOptions>,
  ): MultilateralVisualizerClient;
  service: typeof MultilateralVisualizerService;
  serviceName: string;
};

type Builtin = Date | Function | Uint8Array | string | number | boolean | undefined;

export type DeepPartial<T> = T extends Builtin ? T
  : T extends globalThis.Array<infer U> ? globalThis.Array<DeepPartial<U>>
  : T extends ReadonlyArray<infer U> ? ReadonlyArray<DeepPartial<U>>
  : T extends {} ? { [K in keyof T]?: DeepPartial<T[K]> }
  : Partial<T>;

type KeysOfUnion<T> = T extends T ? keyof T : never;
export type Exact<P, I extends P> = P extends Builtin ? P
  : P & { [K in keyof P]: Exact<P[K], I[K]> } & { [K in Exclude<keyof I, KeysOfUnion<P>>]: never };

function longToNumber(long: Long): number {
  if (long.gt(globalThis.Number.MAX_SAFE_INTEGER)) {
    throw new globalThis.Error("Value is larger than Number.MAX_SAFE_INTEGER");
  }
  return long.toNumber();
}

if (_m0.util.Long !== Long) {
  _m0.util.Long = Long as any;
  _m0.configure();
}

function isSet(value: any): boolean {
  return value !== null && value !== undefined;
}
