#![feature(portable_simd)]

#[macro_use]
mod ops_macros;
impl_signed_tests! { i8 }
