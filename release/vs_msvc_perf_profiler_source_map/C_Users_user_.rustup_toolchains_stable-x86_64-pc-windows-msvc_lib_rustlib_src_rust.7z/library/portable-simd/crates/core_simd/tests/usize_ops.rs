#![feature(portable_simd)]

#[macro_use]
mod ops_macros;
impl_unsigned_tests! { usize }
